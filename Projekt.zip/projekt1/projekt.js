// LOADING PART ////////////////////////////////////////////////////////////////////

function checkIfLoadedFunction(){
	if(document.getElementsByClassName('plnStartClass')[0].innerHTML !== "loading..."){
		$('.preloader').slideUp('slow');
        $('.container-fluid').slideDown('slow');
        clearInterval(loadedCourse);
	}
}

var loadedCourse = setInterval(checkIfLoadedFunction, 1000);

function getRate(from, to) {
	var script = document.createElement('script');
	script.setAttribute('src', "http://query.yahooapis.com/v1/public/yql?q=select%20rate%2Cname%20from%20csv%20where%20url%3D'http%3A%2F%2Fdownload.finance.yahoo.com%2Fd%2Fquotes%3Fs%3D"+from+to+"%253DX%26f%3Dl1n'%20and%20columns%3D'rate%2Cname'&format=json&callback=parseExchangeRate");
	document.body.appendChild(script);
}

function parseExchangeRate(data){
	var rate = parseFloat(data.query.results.row.rate, 10).toFixed(4);
	document.getElementsByClassName('plnStartClass')[0].innerHTML = rate;
	document.getElementsByClassName('plnStartClass')[1].innerHTML = rate;
}

function loadingRateImmediately(){
	if (document.getElementById("pln").innerHTML == 'loading...'){
		getRate("EUR", "PLN");
	}	
	else {
		clearInterval(loadingRateClear);
	} 
}
		
var loadingRateClear = setInterval(loadingRateImmediately, 1000);

var positionNumber = 1;
function loadingRateAfter5Seconds(){
	if(!$('.checkClass').is(':checked') && !$('#resultList').is(':hover')){
		getRate("EUR", "PLN");
		setTimeout(function(){
			refreshFunction();
    	},500);
    	setTimeout(function(){
			sumFunction();
    		highestResultFunction();
    	},1000);
	}
}

setInterval(loadingRateAfter5Seconds, 5000);

// COUNT PART ////////////////////////////////////////////////////////////////////

var transList = [];

function countFunction(){
	if (document.getElementById('idEuro').value != '' && 
		document.getElementById("pln").innerHTML != 'loading...'){
		var courseValue = document.getElementById("pln").innerHTML;
		var euroValue = document.getElementById("idEuro").value;
		var resultValue = +((Math.round((euroValue * courseValue)*10000)/10000).toFixed(4));
		transList.push({position: positionNumber, euro: euroValue, pln: resultValue});
		createCheckboxFunction(transList.length - 1, resultValue);
		positionNumber++;
	}
}

function createCheckboxFunction(a, b){
	var courseValue = document.getElementById("pln").innerHTML;
	var euroValue = document.getElementById("idEuro").value;
	var resultValue = +((Math.round((euroValue * courseValue)*10000)/10000).toFixed(4));
	var title = " " + transList[a].position + "#  " + 
	transList[a].euro + " EURO = " + b + " PLN" + "<br>";
	var element = document.getElementById("resultList");
   	var node = document.createElement('div'); 
   	node.id = "nodeId" + positionNumber;
   	node.className = "nodeClass";
   	node.innerHTML = '<input type="checkbox" class="checkClass" id="check' + positionNumber + 
   	'" name="check' + positionNumber + '"><label id="mainLabel" for="check' + 
   	positionNumber + '">' + title + '</label>';      
   	element.appendChild(node);
}

// DELETE PART ////////////////////////////////////////////////////////////////////

function deleteFunction(){
	for(var i=0; i<=transList.length; i++){
		if($('#check' + i).is(':checked')) {
			$('#nodeId' + i).remove();
			transList[i-1].position = "deleted";
			transList[i-1].pln = 0;
		}
	}
}

// SUM PART ////////////////////////////////////////////////////////////////////

function sumFunction(){
	var allResult = 0;
	for (var i = 0; i < transList.length; i++){
		allResult += +((Math.round((transList[i].pln)*10000)/10000).toFixed(4));
	}
 	document.getElementById("sumAllResult").innerHTML = 
 	+((Math.round((allResult)*10000)/10000).toFixed(4)); 
}

// HIGHEST RESULT PART ////////////////////////////////////////////////////////////////////

function highestResultFunction(){
	document.getElementById("highestResult").innerHTML = "";
	var max = transList.map(function(a) {return a.pln;});
    var max_of_array = Math.max.apply(Math, max);
    var maxResult = "";
    for(var i = 0; i<transList.length; i++){
    	if(transList[i].pln == max_of_array && transList[i].position !== "deleted"){
    		maxResult += "" + transList[i].position + "# " + transList[i].euro + 
    		" EURO = " + transList[i].pln + " PLN" + "<br>";
    		document.getElementById("highestResult").innerHTML = maxResult;
    	}
    } 
}

// REFRESH PART ////////////////////////////////////////////////////////////////////

function refreshFunction(){
	positionNumber = 1;
	document.getElementById("resultList").innerHTML = "";
	for(var i = 0; i <= transList.length; i++){
		if(transList[i].position === "deleted") positionNumber++;
		else{
			var courseValue = document.getElementById("pln").innerHTML;
			var euroValue = transList[i].euro;
			var resultValue = +((Math.round((euroValue * courseValue)*10000)/10000).toFixed(4));
			createCheckboxFunction(i, resultValue);
			transList[i].pln = resultValue;
			positionNumber++;
		}
	}
}

// BUTTONS PART ////////////////////////////////////////////////////////////////////

$(document).ready(function(){
	$("#countButton").click(function(){
		countFunction();
		sumFunction();
		highestResultFunction();
	});
});

$(document).ready(function(){
	$("#deleteButton").click(function(){
		deleteFunction();
		sumFunction();
		highestResultFunction();
	});
});